package edu.heinz.ds.androidinterestingpicture;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
/**
 * Work Cited:<a href="https://canvas.cmu.edu/courses/39210/pages/android-lab?module_item_id=5694679">...</a>
 * MainActivity serves as the main interface of the application, handling user interactions,
 * web service communication, and UI updates. It fulfills the following functionalities:
 * a. Requires input from the user for version and abbreviation parameters.
 * b. Makes an HTTP request to a web service using the GET method.
 * c. Parses the JSON formatted response from the web service.
 * d. Displays new information (Bible verses) to the user in a ListView.
 * e. Allows the user to repeatedly use the application without restarting it.
 */
public class MainActivity extends AppCompatActivity {

    private EditText version;
    private EditText abbrev;
    private MaterialButton btn;
    private ListView listview;
    private final static int SUCCESS = 1;
    private final static int FAILE = 0;
    /**
     * Handles messages from the web service communication, updating the UI based on the success or failure of operations.
     * On success, it parses the JSON response and updates the ListView. On failure, it shows a toast message.
     */
    @SuppressLint("HandlerLeak")
    private Handler mHandler = new Handler() {
        public void handleMessage(Message msg) {
            String response;
            switch (msg.what) {
                case SUCCESS:
                    response = msg.obj.toString();
                    Log.d("zzz", "handleMessage: " + response);
                    try {
                        // JSONObject
                        JSONObject jsonObject = new JSONObject(response);
                        if (jsonObject.get("code").equals("200")) {
                            String s = jsonObject.getString("data");
                            jsonObject = new JSONObject(s);
                            JSONArray jsonArray = (JSONArray) jsonObject.get("verseList");
                            List<String> list = new ArrayList<>();
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject o = (JSONObject) jsonArray.get(i);
                                Log.d("zzz", "handleMessage: " + o.getString("text"));
                                list.add(o.getString("text"));
                            }
                            listview.setAdapter(new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, list));
                        } else {
                            Toast.makeText(MainActivity.this, jsonObject.getString("msg"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    break;
                case FAILE:
                    response = msg.obj.toString();
                    Toast.makeText(MainActivity.this, response, Toast.LENGTH_SHORT).show();
                    Log.d("zzz", "handleMessage: " + response);
                    break;
            }
        }
        ;
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        initView();
        initData();
    }
    /**
     * Sets up the application's data handling, specifically the button click listener to trigger the HTTP request.
     */
    private void initData() {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = version.getText().toString();
                String s2 = abbrev.getText().toString();
                if (TextUtils.isEmpty(s1) || TextUtils.isEmpty(s2)) {
                    Toast.makeText(MainActivity.this, "Incomplete input content", Toast.LENGTH_SHORT).show();
                    return;
                }
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        HttpURLConnection connection = null;
                        try {
                            //Local service   -->ip:port/project4task2
                            //git code space  -->>  https://vigilant-pancake-jjjxq75965w7fjpjr-8080.app.github.dev
                            URL url = new URL("https://solid-meme-4jjxwv764jrw276j6-8080.app.github.dev/abibliadigitalApi?version=" + s1 + "&abbrev=" + s2);
                            connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("GET");
                            InputStream in = connection.getInputStream();
                            BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(in));
                            String response = "", line;
                            while ((line = reader.readLine()) != null) {
                                response += line;
                            }
                            Message message = new Message();
                            message.what = SUCCESS;
                            message.obj = response;
                            mHandler.sendMessage(message);
                        } catch (Exception e) {
                            Message message = new Message();
                            message.what = FAILE;
                            message.obj = "request was aborted";
                            mHandler.sendMessage(message);
                            e.printStackTrace();
                        } finally {
                            if (connection != null) {
                                connection.disconnect();
                            }
                        }
                    }

                }).start();
            }
        });
    }
    /**
     * Initializes the view components of the application, binding them to their respective UI elements.
     */
    private void initView() {
        version = (EditText) findViewById(R.id.version);
        abbrev = (EditText) findViewById(R.id.abbrev);
        btn = (MaterialButton) findViewById(R.id.btn);
        listview = (ListView) findViewById(R.id.listview);
    }
}