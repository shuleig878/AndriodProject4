package org.shuleii.common;

import java.util.Random;

/**
 * CommonUtils
 */
public class CommonUtils {
    public static int generateRandomNumber(int start, int end) {
        if (start > end) {
            throw new IllegalArgumentException("Start number cannot be greater than end number");
        }
        Random random = new Random();
        return random.nextInt(end - start + 1) + start;
    }
}
