package org.shuleii.common;

import com.mongodb.client.*;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;
import org.shuleii.model.LogRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * MongoDBUtils
 */
public class MongoDBUtils {
    private static final Logger logger = LoggerFactory.getLogger(MongoDBUtils.class);

    //Database name
    private static final String LOGRECORD_DATABASE = "project4";

    //COLLECTION name
    private static final String LOGRECORD_COLLECTION = "apiLogRecord";

    /**
     * @param logRecord
     * @description: addMovie
     * @author: shuleli
     * @return:
     */
    public Boolean addLogRecord(LogRecord logRecord) {
        // Connect to the MongoDB service
        try (MongoClient mongoClient = MongoClients.create(ConfigUtil.getMongoDBUri())) {
            //Selective database
            MongoDatabase database = mongoClient.getDatabase(LOGRECORD_DATABASE);

            // Selection set
            MongoCollection<Document> collection = database.getCollection(LOGRECORD_COLLECTION);

            // Create movie information to insert
            Document document = new Document()
                    .append("id", logRecord.getId())
                    .append("request", logRecord.getRequest())
                    .append("response", logRecord.getResponse())
                    .append("requestTime", logRecord.getRequestTime());

            // Insert document
            InsertOneResult insertOneResult = collection.insertOne(document);

            logger.info("add res:" + insertOneResult.wasAcknowledged());
            return insertOneResult.wasAcknowledged();
        } catch (Exception e) {
            logger.error("add LogRecord error", e);
        }
        return false;
    }

    /**
     * @description: listMovie
     * @author: shuleli
     * @return:
     */
    public List<LogRecord> listLogRecord() {
        // Connect to the MongoDB service
        List<LogRecord> logRecords = new ArrayList<>();
        try (MongoClient mongoClient = MongoClients.create(ConfigUtil.getMongoDBUri())) {
            // Selective database
            MongoDatabase database = mongoClient.getDatabase(LOGRECORD_DATABASE);
            // Selection set
            MongoCollection<Document> collection = database.getCollection(LOGRECORD_COLLECTION);

            // Execute the query to get all documents
            MongoCursor<Document> cursor = collection.find()
                    .sort(Sorts.descending("requestTime"))
                    .iterator();

            try {
                while (cursor.hasNext()) {
                    Document document = cursor.next();
                    String id = document.getString("id");
                    String request = document.getString("request");
                    String response = document.getString("response");
                    Date requestTime = document.getDate("requestTime");
                    logRecords.add(new LogRecord(id, request, response, requestTime));
                }
            } finally {
                cursor.close();
            }
        } catch (Exception e) {
            logger.error("list LogRecord error", e);
        }
        return logRecords;
    }


    /**
     * @description: deleteAllLogRecords
     * @author: shuleli
     * @return: void
     */
    public void deleteAllLogRecords() {
        try (MongoClient mongoClient = MongoClients.create(ConfigUtil.getMongoDBUri())) {
            // Selective database
            MongoDatabase database = mongoClient.getDatabase(LOGRECORD_DATABASE);
            // Selection set
            MongoCollection<Document> collection = database.getCollection(LOGRECORD_COLLECTION);

            // Delete all documents in the collection
            collection.deleteMany(new Document());

            logger.info("All log records deleted successfully.");
        } catch (Exception e) {
            logger.error("Failed to delete all log records", e);
        }
    }


    public static void main(String[] args) {
        MongoDBUtils mongoDBUtils = new MongoDBUtils();

//        mongoDBUtils.addLogRecord(new LogRecord("1", "1", "2", new Date()));
//
//        List<LogRecord> logRecords = mongoDBUtils.listLogRecord();
//        System.out.println(logRecords);
        mongoDBUtils.deleteAllLogRecords();
    }

}
