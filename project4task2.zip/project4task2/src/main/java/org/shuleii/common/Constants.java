package org.shuleii.common;

/**
 * Constants
 */
public interface Constants {
    //Success  return code
    String SUCCESS_CODE = "200";

    //Fail  return code
    String FAIL_CODE = "500";
}











