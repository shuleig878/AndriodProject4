package org.shuleii.common;

import com.google.gson.*;
import org.shuleii.ex.ServiceException;
import org.shuleii.model.Chapter;
import org.shuleii.model.LogRecord;
import org.shuleii.model.Verse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

/**
 * Invoke third-party API interfaces
 * user task1-1 -->Api
 *
 * use https://www.abibliadigital.com.br/en api   ->>  https://www.abibliadigital.com.br/en
 */
public class BibleVerseApiUtils {

    private static final Logger logger = LoggerFactory.getLogger(BibleVerseApiUtils.class);

    /*
        Get Versions - returns all Bible versions and number of verses
        Endpoint: GET https://www.abibliadigital.com.br/api/versions
        [
          {
              "version": "acf",
              "verses": 31106
          },
          {
              "version": "apee",
              "verses": 30975
          },
          {
              "version": "bbe",
              "verses": 31104
          }
        ]
     */
    private static final String VERSION = "acf";

    /*
        Get Books - returns list of 66 bible books
        Endpoint: GET https://www.abibliadigital.com.br/api/books
        Authenticated:
        No - Limit rate of 20 requests per hour
        Yes - Unlimited
        [
            {
                "abbrev": {
                    "pt": "gn",
                    "en": "gn"
                },
                "author": "Moisés",
                "chapters": 50,
                "group": "Pentateuco",
                "name": "Gênesis",
                "testament": "VT"
            },
            {
                "abbrev": {
                    "pt": "ex",
                    "en": "ex"
                },
                "author": "Moisés",
                "chapters": 40,
                "group": "Pentateuco",
                "name": "Êxodo",
                "testament": "VT"
            },......
        [
     */
    private static final String ABBREV = "gn";

    //RANDOM MAX
    private static final Integer RANDOM_MAX = 50;

    /*
        Interface source  --》   https://github.com/omarciovsena/abibliadigital/blob/master/DOCUMENTATION.md/
        Get Random Verse Book - return a verse from a specific book
     */
    private static final String API_URL = "https://www.abibliadigital.com.br/api/verses/%s/%s/%s";

    private MongoDBUtils mongoDBUtils = new MongoDBUtils();

    public static void main(String[] args) {
        BibleVerseApiUtils bibleVerseApiUtils = new BibleVerseApiUtils();
        bibleVerseApiUtils.sendRequest();
    }

    public Chapter sendRequest() {
        return sendRequest(VERSION, ABBREV);
    }

    /**
     * @param version
     * @param abbrev
     * @description:
     * @author:
     * @return:
     */
    public Chapter sendRequest(String version, String abbrev) {
        HttpURLConnection conn = null;
        BufferedReader reader = null;
        try {
            String apiUlr = String.format(API_URL, version, abbrev, CommonUtils.generateRandomNumber(1, RANDOM_MAX));

            URL url = new URL(apiUlr);

            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            Gson gson = new GsonBuilder().create();

            JsonObject jsonObject = null;
            try {
                jsonObject = gson.fromJson(response.toString(), JsonObject.class);
            } catch (Exception e) {
                throw new IllegalArgumentException(response.toString());
            }

            JsonObject chapterJson = jsonObject.getAsJsonObject("chapter");

            //verses
            JsonArray versesArray = jsonObject.getAsJsonArray("verses");

            Chapter chapter = gson.fromJson(chapterJson.toString(), Chapter.class);

            List<Verse> verses = new ArrayList<>();
            for (JsonElement element : versesArray) {
                Verse verse = gson.fromJson(element, Verse.class);
                verses.add(verse);
            }

            if (Objects.nonNull(verses) && verses.size() > 0) {
                chapter.setVerseList(verses);
            } else {
                chapter.setVerseList(Collections.EMPTY_LIST);
            }

            //inset LogRecord to mongodb...
            JsonObject reqParam = new JsonObject();
            reqParam.addProperty("version", version);
            reqParam.addProperty("abbrev", abbrev);
            mongoDBUtils.addLogRecord(new LogRecord(UUID.randomUUID().toString(), reqParam.toString(), gson.toJson(chapter), new Date()));

            return chapter;
        } catch (Exception e) {
//            System.out.println("An error occurred: " + e);
            logger.error("The third-party API call failed!", e);
            throw new ServiceException("The third-party API call failed: " + e.getMessage());
        } finally {
            if (Objects.nonNull(reader)) {
                try {
                    reader.close();
                } catch (Exception e) {
                    System.out.println("reader close error ");
                }
            }
            if (Objects.nonNull(conn)) {
                conn.disconnect();
            }
        }
    }


}
