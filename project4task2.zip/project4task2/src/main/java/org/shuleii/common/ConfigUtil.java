package org.shuleii.common;

import java.io.InputStream;
import java.util.Properties;

/**
 * ConfigUtil
 */
public class ConfigUtil {

    private static final String CONFIG_FILE = "application.properties";

    private static final String MONGODB_URI_PROPERTY = "mongodb.uri";

    public static String getMongoDBUri() {
        Properties prop = new Properties();
        try (InputStream input = ConfigUtil.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            prop.load(input);
            return prop.getProperty(MONGODB_URI_PROPERTY);
        } catch (Exception e) {
            System.err.println("An error occurred when reading the configuration file: " + e);
            throw new IllegalArgumentException("An error occurred when reading the configuration file:");
        }
    }
}
