package org.shuleii.model;

/**
 * book. Verse
 *
 * @createDate: 2024/04/02 14:29
 */
public class Verse {
    private int number;
    private String text;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
