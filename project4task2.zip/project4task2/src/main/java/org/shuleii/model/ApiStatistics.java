package org.shuleii.model;

import java.io.Serializable;
import java.util.List;

/**
 * ApiStatistics
 */
public class ApiStatistics implements Serializable {

    //lastAccessTime
    private String lastAccessTime;

    //count
    private Integer count;

    //useMostVersion
    private String useMostVersion;

    private List<Integer> pieChartDatas;

    private List<String> versions;

    public List<String> getVersions() {
        return versions;
    }

    public void setVersions(List<String> versions) {
        this.versions = versions;
    }

    public String getLastAccessTime() {
        return lastAccessTime;
    }

    public void setLastAccessTime(String lastAccessTime) {
        this.lastAccessTime = lastAccessTime;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getUseMostVersion() {
        return useMostVersion;
    }

    public void setUseMostVersion(String useMostVersion) {
        this.useMostVersion = useMostVersion;
    }

    public List<Integer> getPieChartDatas() {
        return pieChartDatas;
    }

    public void setPieChartDatas(List<Integer> pieChartDatas) {
        this.pieChartDatas = pieChartDatas;
    }
}
