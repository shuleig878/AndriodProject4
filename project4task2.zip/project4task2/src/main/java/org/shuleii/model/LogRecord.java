package org.shuleii.model;

import java.io.Serializable;
import java.util.Date;

/**
 * It is used to record APP requests and corresponding information
 *
 * @createDate: 2024/04/02 12:07
 */
public class LogRecord implements Serializable {

    private String id;

    private String request;

    private String response;

    private Date requestTime;

    public LogRecord(String id, String request, String response, Date requestTime) {
        this.id = id;
        this.request = request;
        this.response = response;
        this.requestTime = requestTime;
    }

    public LogRecord() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Date getRequestTime() {
        return requestTime;
    }

    public void setRequestTime(Date requestTime) {
        this.requestTime = requestTime;
    }

    @Override
    public String toString() {
        return "LogRecord{" +
                "id='" + id + '\'' +
                ", request='" + request + '\'' +
                ", response='" + response + '\'' +
                ", requestTime=" + requestTime +
                '}';
    }
}
