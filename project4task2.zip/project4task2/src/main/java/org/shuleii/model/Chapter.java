package org.shuleii.model;

import java.util.List;

/**
 * <Description>
 *
 *
 * @createDate: 2024/04/02 14:29
 */
public class Chapter {
    private int number;
    private int verses;
    private List<Verse> verseList;

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getVerses() {
        return verses;
    }

    public void setVerses(int verses) {
        this.verses = verses;
    }

    public List<Verse> getVerseList() {
        return verseList;
    }

    public void setVerseList(List<Verse> verseList) {
        this.verseList = verseList;
    }
}
