package org.shuleii.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.shuleii.common.MongoDBUtils;
import org.shuleii.model.ApiStatistics;
import org.shuleii.model.LogRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * HttpServlet returns
 * <p>
 * DashboardServlet
 */
@WebServlet(name = "dashboard",
        urlPatterns = {"/dashboard"})
public class DashboardServlet extends HttpServlet {
    private static final Logger logger = LoggerFactory.getLogger(DashboardServlet.class);

    private List<String> versions = new ArrayList<>(Arrays.asList("acf", "apee", "bbe", "kjv", "nvi", "ra", "rvr"));

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Forward the request to the dashboard.jsp.bak inside WEB-INF
        // req.getRequestDispatcher("/WEB-INF/dashboard.jsp.bak").forward(req, resp);
        response.setContentType("text/plain; charset=UTF-8");
        try {
            //logDataList
            MongoDBUtils mongoDBUtils = new MongoDBUtils();
            List<LogRecord> logRecords = mongoDBUtils.listLogRecord();
            request.setAttribute("logDataList", logRecords);

            //apiStatistics
            ApiStatistics apiStatistics = getApiStatistics(logRecords);
            request.setAttribute("apiStatistics", apiStatistics);

            RequestDispatcher view = request.getRequestDispatcher("/WEB-INF/dashboard.jsp");
            view.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public ApiStatistics getApiStatistics(List<LogRecord> logRecords) {
        ApiStatistics apiStatistics = new ApiStatistics();
        apiStatistics.setVersions(versions);
        if (Objects.isNull(logRecords) && logRecords.isEmpty()) {
            List<Integer> pieChartDatas = new ArrayList<>();
            for (String ver : versions) {
                pieChartDatas.add(0);
            }
            return apiStatistics;
        }
        Gson gson = new GsonBuilder().create();

        // Get the record with the most time
        LogRecord maxRecord = logRecords.stream()
                .max(Comparator.comparing(LogRecord::getRequestTime))
                .orElse(null);
        if (Objects.nonNull(maxRecord)) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            apiStatistics.setLastAccessTime(sdf.format(maxRecord.getRequestTime()));
        }

        // Get total quantity
        apiStatistics.setCount(logRecords.size());

        //
        Map<String, Integer> versionMap = new HashMap<>();
        for (LogRecord logRecord : logRecords) {
            String request = logRecord.getRequest();
            JsonObject requestJson = gson.fromJson(request, JsonObject.class);
            JsonElement version = requestJson.get("version");

            if (Objects.isNull(versionMap.get(version.getAsString()))) {
                versionMap.put(version.getAsString(), 1);
            } else {
                versionMap.put(version.getAsString(), versionMap.get(version.getAsString()) + 1);
            }
        }

        List<Integer> pieChartDatas = new ArrayList<>();
        for (String ver : versions) {
            Integer num = versionMap.get(ver);
            pieChartDatas.add(Objects.nonNull(num) ? num : 0);
        }
        apiStatistics.setPieChartDatas(pieChartDatas);

        Map.Entry<String, Integer> maxEntry = versionMap.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);
        if (Objects.nonNull(maxEntry)) {
            apiStatistics.setUseMostVersion(maxEntry.getKey());
        }

        return apiStatistics;
    }
}
