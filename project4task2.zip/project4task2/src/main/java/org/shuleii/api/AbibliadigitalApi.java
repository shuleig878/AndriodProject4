package org.shuleii.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.shuleii.common.BibleVerseApiUtils;
import org.shuleii.common.Constants;
import org.shuleii.common.Result;
import org.shuleii.model.Chapter;
import java.io.IOException;
import java.util.Objects;

/**
 * @createDate: 2024/04/02 14:42
 * <p>Work Cited:https://www.abibliadigital.com.br/en; Chatgpt; https://github.com/omarciovsena/abibliadigital/blob/master/DOCUMENTATION.md/
 * http://localhost:8080/abibliadigitalApi?version=1&abbrev=2
 */
@WebServlet(name = "abibliadigita",
        urlPatterns = {"/abibliadigita"})
public class AbibliadigitalApi extends HttpServlet {

    // BibleVerseApiUtils
    private BibleVerseApiUtils bibleVerseApiUtils = new BibleVerseApiUtils();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/plain; charset=UTF-8");
        Gson gson = new GsonBuilder().create();
        Result<Chapter> result = new Result<>();
        try {
            String version = request.getParameter("version");
            if (Objects.isNull(version) || version.isEmpty()) {
                throw new IllegalArgumentException("version cannot be empty!");
            }
            String abbrev = request.getParameter("abbrev");
            if (Objects.isNull(abbrev) || abbrev.isEmpty()) {
                throw new IllegalArgumentException("abbrev cannot be empty!");
            }

            Chapter chapter = bibleVerseApiUtils.sendRequest(version, abbrev);
            if (Objects.nonNull(chapter)) {
                result.setCode(Constants.SUCCESS_CODE);
                result.setData(chapter);
            }
            // Set the response content type to JSON
            response.setContentType("application/json");
            response.getWriter().write(gson.toJson(result));
        } catch (Exception e) {
            result.setCode(Constants.FAIL_CODE);
            result.setMsg(e.getMessage());
            response.getWriter().write(gson.toJson(result));
        }
    }

}
